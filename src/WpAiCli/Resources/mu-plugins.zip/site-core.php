<?php
/**
 * Plugin Name: Site Core Loader
 * Description: Load site-specific mu-plugins.
 */
foreach (glob(__DIR__ . '/site-core/*.php') as $file) {
    require_once $file;
}
