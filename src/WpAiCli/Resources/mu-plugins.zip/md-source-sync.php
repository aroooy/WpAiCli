<?php
/**
 * Must-Use Plugin: MD Source Sync (no transform)
 * Description: _md_source の内容を編集画面で表示し、保存時に _md_source と post_content の両方へ“生Markdown”を保存。
 * Version: 0.1.0
 */

if (!defined('ABSPATH')) exit;

define('MDS_META_KEY', '_md_source');
define('MDS_FIELD',    'mds_source_field');
define('MDS_NONCE',    'mds_source_nonce');

/**
 * メタボックス追加（Gutenbergでも下部に出ます）
 */
add_action('add_meta_boxes', function () {
    $post_types = apply_filters('mds_post_types', ['post', 'page']); // 必要ならCPTを追加
    foreach ($post_types as $pt) {
        add_meta_box(
            'mds_meta_box',
            __('Markdown Source (_md_source)', 'mds'),
            'mds_render_box',
            $pt,
            'normal',
            'high'
        );
    }
});

function mds_render_box($post) {
    $val = get_post_meta($post->ID, MDS_META_KEY, true);
    wp_nonce_field('mds_save', MDS_NONCE);
    echo '<p style="margin:0 0 8px;color:#666;">保存時に <code>' . esc_html(MDS_META_KEY) . '</code> と <code>post_content</code> の両方へ“生Markdown”を保存します（変換しません）。</p>';
    echo '<textarea name="'.esc_attr(MDS_FIELD).'" rows="18" style="width:100%;font-family:monospace;">'
       . esc_textarea($val) . '</textarea>';
}

/**
 * 保存直前に post_content を“生Markdown”で差し替え
 */
add_filter('wp_insert_post_data', function ($data, $postarr) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return $data;
    if (empty($_POST[MDS_NONCE]) || !wp_verify_nonce($_POST[MDS_NONCE], 'mds_save')) return $data;

    $post_id = isset($postarr['ID']) ? intval($postarr['ID']) : 0;
    if ($post_id && !current_user_can('edit_post', $post_id)) return $data;

    // フィールド未送信なら何もしない（空で上書きしたい場合は条件を調整）
    if (!array_key_exists(MDS_FIELD, $_POST)) return $data;

    $md_raw = wp_unslash($_POST[MDS_FIELD]); // “生Markdown”
    $data['post_content'] = $md_raw;         // ← 変換せずそのまま

    return $data;
}, 10, 2);

/**
 * メタ保存（_md_source へ“生Markdown”を保持）
 */
add_action('save_post', function ($post_id, $post) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    if (empty($_POST[MDS_NONCE]) || !wp_verify_nonce($_POST[MDS_NONCE], 'mds_save')) return;
    if (!current_user_can('edit_post', $post_id)) return;

    if (array_key_exists(MDS_FIELD, $_POST)) {
        $md_raw = wp_unslash($_POST[MDS_FIELD]);
        update_post_meta($post_id, MDS_META_KEY, $md_raw);
    }
}, 10, 2);
